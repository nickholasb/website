apt install pv -y

apt install figlet -y

termux-storage-setup -y

apt install ruby -y
apt install python -y
apt install php -y
gem install lolcat

apt install p7zip -y
xdg-open https://wa.me/+6285811424922
7z x ids-inf.7z -pnidhin123
cd ids-inf


7z x ids_tool.7z -pids123
cd ids_tool
cd ids_tool
bash ids3.sh
