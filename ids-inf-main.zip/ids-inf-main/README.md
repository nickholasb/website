# ids-inf
this tool is created for ids
in this script we has added information gathering 
and number ban unban + mail sending script 
you can track any number and take its information 
and it also have ip phishing and tracking options
and fb , insta information gathering .
This tool is created by shell script and python 

<img src="https://github.com/DRACULA-HACK/ids-inf/blob/main/IMG_20230321_215629.jpg" alt="idstool">

#
# Features
* phone number information gathering 
#
* ip tracker and ip phisher
#
* number ban and unban (mail)
#
* SOCIAL MEDIA information gathering 
#
* number ban methods 
#

# for termux users

# updated the 5th option 

# TERMUX 


` apt install pv -y `

` apt install figlet -y `

` termux-setup-storage -y `

` apt install ruby -y `

` gem install lolcat `

#
`git clone https://github.com/DRACULA-HACK/ids-inf `
#
* `cd ids-inf `
#
` python3 -m pip install -r requirements.txt `
#
* ` bash start-ids.sh `

#
after extracting the files you can run `ids.sh` 

#
` bash ids.sh `

# INVADERS OFC 
#


 
  
     
      
  
#

# instagram 

<a href="https://instagram.com/_invaders_ofc_?igshid=MTg0ZDhmNDA=">Visit instagram </a> 

# youtube
 
<a href="https://m.youtube.com/channel/UCcuJQhSiU80wigeMyHu9r_g">YOU TUBE </a>
#
# WHATSAPP
<a href="https://wa.me//+916235369260">WHATSAPP </a>
#
created 
by 
master-hack

#

<img src="https://github.com/DRACULA-HACK/ids-inf/blob/main/IMG_20221219_104937.jpg" alt="alternatetext">

#
