cd ids-inf
cd ids_tool
cd ids_tool
bash ids3.sh
